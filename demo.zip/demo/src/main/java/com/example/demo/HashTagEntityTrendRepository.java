package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class HashTagEntityTrendRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	class HashTagEntityTrendRowMapper implements RowMapper<HashTagEntityTrend> {
		
		@Override
		public HashTagEntityTrend mapRow(ResultSet rs, int rowNum) throws SQLException {
			HashTagEntityTrend hashtag = new HashTagEntityTrend();
			hashtag.setId(rs.getLong("ID"));
			hashtag.setHashTagName(rs.getString("TAG_NAME"));
			hashtag.setHashTagCount(rs.getInt("TAG_COUNT"));
			return hashtag;
		}

	}
	
	public int insert(HashTagEntityTrend hashTag) {
		return jdbcTemplate.update("insert into HASH_TAG_TREND (ID, TAG_NAME, TAG_COUNT) " + "values(?,  ?, ?)",
				new Object[] { hashTag.getId(), hashTag.getHashTagName(), hashTag.getHashTagCount() });
	}
	
	public int findByTagCount(String name) {
        String sql = "SELECT TAG_COUNT FROM HASH_TAG_TREND WHERE TAG_NAME = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{name}, Integer.class);
    }
	
	public int updateTrendCount(int count, String tagName) {
		String sqlupdate = "UPDATE HASH_TAG_TREND SET TAG_COUNT=? WHERE TAG_NAME=?";
		return jdbcTemplate.update(sqlupdate, count, tagName);
	}
	
	
	public List<HashTagEntityTrend> findAll() {
        return jdbcTemplate.query(
                "SELECT * FROM HASH_TAG_TREND ORDER BY TAG_COUNT DESC;",
                (rs, rowNum) ->
                        new HashTagEntityTrend(
                        		rs.getLong("ID"),
                                rs.getString("TAG_NAME"),
                                rs.getInt("TAG_COUNT")
                        )
        );
    }
}
