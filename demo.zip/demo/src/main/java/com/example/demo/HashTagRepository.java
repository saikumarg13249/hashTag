package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class HashTagRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	class HashTagEntityRowMapper implements RowMapper<HashTagEntity> {
		
		@Override
		public HashTagEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
			HashTagEntity hashtag = new HashTagEntity();
			hashtag.setId(rs.getLong("ID"));
			hashtag.setTagName(rs.getString("TAG_NAME"));
			hashtag.setTagValue(rs.getString("TAG_VALUE"));
			return hashtag;
		}

	}
	
	public int insert(HashTagEntity hashTag) {
		return jdbcTemplate.update("insert into HASHTAG (ID, TAG_NAME, TAG_VALUE) " + "values(?,  ?, ?)",
				new Object[] { hashTag.getId(), hashTag.getTagName(), hashTag.getTagValue() });
	}
	
	public int  getTagNameCount(String tagName) {
		String sql = "SELECT COUNT(TAG_NAME) FROM HASHTAG WHERE TAG_NAME = ?";
		return  jdbcTemplate.queryForObject(sql, new Object[]{tagName},Integer.class);
	}
}
