package com.example.demo;

public class HashTagEntityTrend {
	
	private Long id;
	private String hashTagName;
	private int hashTagCount;
	
	public HashTagEntityTrend() {
		
	}
	
	public HashTagEntityTrend(Long id, String hashTagName, int hashTagCount) {
		this.id= id;
		this.hashTagName = hashTagName;
		this.hashTagCount = hashTagCount;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getHashTagName() {
		return hashTagName;
	}
	public void setHashTagName(String hashTagName) {
		this.hashTagName = hashTagName;
	}
	public int getHashTagCount() {
		return hashTagCount;
	}
	public void setHashTagCount(int hashTagCount) {
		this.hashTagCount = hashTagCount;
	}
	
	
	

}
